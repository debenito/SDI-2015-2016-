package uo.sdi.model;

public enum UserStatus {
	ACTIVE,
	CANCELLED
}

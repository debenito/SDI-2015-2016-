package uo.sdi.model;

public enum SeatStatus {
	ACCEPTED,
	EXCLUDED
}

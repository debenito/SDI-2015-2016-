package uo.sdi.model;

public enum TripStatus {
	OPEN, 
	CLOSED,
	CANCELLED,
	DONE
}
